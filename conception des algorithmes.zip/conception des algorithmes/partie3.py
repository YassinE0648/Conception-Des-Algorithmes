import matplotlib.pyplot as plt
import numpy as np
import matplotlib.animation as animation

#definition du graphe pour le test 
graph = {
    'A': ['B', 'C'],
    'B': ['C', 'D', 'F'],
    'C': ['B', 'D', 'E'],
    'D': ['B', 'C', 'E','G','E'],
    'E': ['C', 'D', 'G'],
    'F': ['B', 'D', 'G'],
    'G': ['F','D','E']
}

positions = {
    'A': (0, 1),
    'B': (1, 2),
    'C': (1, 0),
    'D': (2, 1),
    'E': (3, 0),
    'F': (3, 2),
    'G': (4, 1)
}

# Fonction de parcours en largeur
def bfs(graph, start):
    visited = []
    queue = [start]
    steps = []

    while queue:
        node = queue.pop(0)#en prend le premier element utilisant pop(0)
        if node not in visited:
            visited.append(node)        #l'ajout de l'element 
            steps.append(visited[:])    # Capture l'état actuel du parcours
            neighbors = graph[node]
            for neighbor in neighbors:          #en fait un test sur les voisines
                if neighbor not in visited:     #je test si le visin n'appartienne pas au list
                    queue.append(neighbor)      #ajoute de le voisin au list queue
    
    return steps


# Fonction pour dessiner le graphe
def draw_graph(steps, ax):
    ax.clear()
    for node, pos in positions.items():
        ax.plot(pos[0], pos[1], 'o', color='gray' if node not in steps else 'red', markersize=15)
        ax.text(pos[0], pos[1], node, fontsize=12, ha='center', va='center', color='white')
    for node, neighbors in graph.items():
        for neighbor in neighbors:
            x_values = [positions[node][0], positions[neighbor][0]]
            y_values = [positions[node][1], positions[neighbor][1]]
            ax.plot(x_values, y_values, 'gray')


# Fonction d'animation
def animate(i):
    draw_graph(steps[i], ax)
    

# Initialiser la figure et l'axe
fig, ax = plt.subplots()
ax.axis('off')


# Obtenir les étapes du parcours
steps = bfs(graph, 'A')


# Créer l'animation
ani = animation.FuncAnimation(fig, animate, frames=len(steps), interval=1000, repeat=False)


# Afficher l'animation
plt.show()